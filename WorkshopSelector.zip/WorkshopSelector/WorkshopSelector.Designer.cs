﻿
namespace WorkshopSelector
{
    partial class WorkshopSelector
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager1 = new Krypton.Toolkit.KryptonManager(this.components);
            this.workshopListBox = new Krypton.Toolkit.KryptonListBox();
            this.kryptonLabel1 = new Krypton.Toolkit.KryptonLabel();
            this.cityListBox = new Krypton.Toolkit.KryptonListBox();
            this.cityLabel = new Krypton.Toolkit.KryptonLabel();
            this.registrationTextBox = new Krypton.Toolkit.KryptonTextBox();
            this.calculateButton = new Krypton.Toolkit.KryptonButton();
            this.exitButton = new Krypton.Toolkit.KryptonButton();
            this.SuspendLayout();
            // 
            // kryptonManager1
            // 
            this.kryptonManager1.GlobalPaletteMode = Krypton.Toolkit.PaletteModeManager.SparkleBlue;
            // 
            // workshopListBox
            // 
            this.workshopListBox.Items.AddRange(new object[] {
            "Handling Stress               3               $1,000",
            "Time Management          3               $800",
            "Supervision Skills             3               $1,500",
            "Negotiation                     5               $1,300",
            "How to Interview             1               $500"});
            this.workshopListBox.Location = new System.Drawing.Point(43, 110);
            this.workshopListBox.Name = "workshopListBox";
            this.workshopListBox.Size = new System.Drawing.Size(410, 114);
            this.workshopListBox.TabIndex = 0;
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.Location = new System.Drawing.Point(43, 49);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.Size = new System.Drawing.Size(321, 24);
            this.kryptonLabel1.TabIndex = 1;
            this.kryptonLabel1.Values.Text = "Workshop/Number of Days/Registration Fees";
            // 
            // cityListBox
            // 
            this.cityListBox.Items.AddRange(new object[] {
            "Austin               $150",
            "Chicago            $225",
            "Dallas               $175",
            "Orlando            $300",
            "Pheonix             $175",
            "Raleigh              $150"});
            this.cityListBox.Location = new System.Drawing.Point(513, 110);
            this.cityListBox.Name = "cityListBox";
            this.cityListBox.Size = new System.Drawing.Size(223, 135);
            this.cityListBox.TabIndex = 2;
            // 
            // cityLabel
            // 
            this.cityLabel.Location = new System.Drawing.Point(513, 49);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(223, 24);
            this.cityLabel.TabIndex = 3;
            this.cityLabel.Values.Text = "Location/Lodging Fees per Day";
            // 
            // registrationTextBox
            // 
            this.registrationTextBox.Enabled = false;
            this.registrationTextBox.Location = new System.Drawing.Point(43, 242);
            this.registrationTextBox.Multiline = true;
            this.registrationTextBox.Name = "registrationTextBox";
            this.registrationTextBox.Size = new System.Drawing.Size(410, 115);
            this.registrationTextBox.TabIndex = 4;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(513, 257);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(112, 31);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Values.Text = "Calculate";
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(513, 299);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 31);
            this.exitButton.TabIndex = 6;
            this.exitButton.Values.Text = "Exit";
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // WorkshopSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.registrationTextBox);
            this.Controls.Add(this.cityLabel);
            this.Controls.Add(this.cityListBox);
            this.Controls.Add(this.kryptonLabel1);
            this.Controls.Add(this.workshopListBox);
            this.Name = "WorkshopSelector";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Krypton.Toolkit.KryptonManager kryptonManager1;
        private Krypton.Toolkit.KryptonListBox workshopListBox;
        private Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private Krypton.Toolkit.KryptonListBox cityListBox;
        private Krypton.Toolkit.KryptonLabel cityLabel;
        private Krypton.Toolkit.KryptonTextBox registrationTextBox;
        private Krypton.Toolkit.KryptonButton calculateButton;
        private Krypton.Toolkit.KryptonButton exitButton;
    }
}

