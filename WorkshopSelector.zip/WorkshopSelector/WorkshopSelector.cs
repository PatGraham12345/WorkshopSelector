﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopSelector
{
    public partial class WorkshopSelector : Krypton.Toolkit.KryptonForm
    {
        public WorkshopSelector()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Makes the neccessary calculations and outputs the result to a text box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Initializers
            int numberOfDays = 0;
            double lodgingFees = 0;
            double totalLodgingFees = 0;
            double registrationFees = 0;
            double totalFees = 0;
            StringBuilder workshopInfoBuilder = new StringBuilder();

            //Sets the values for the number of days and registration fee.
            if (workshopListBox.SelectedIndex != -1 && cityListBox.SelectedIndex != -1)
            {
                switch (workshopListBox.SelectedIndex)
                {
                    case 0:
                        numberOfDays = 3;
                        registrationFees = 1000;
                        break;
                    case 1:
                        numberOfDays = 3;
                        registrationFees = 800;
                        break;
                    case 2:
                        numberOfDays = 3;
                        registrationFees = 1500;
                        break;
                    case 3:
                        numberOfDays = 5;
                        registrationFees = 1300;
                        break;
                    case 4:
                        numberOfDays = 1;
                        registrationFees = 500;
                        break;
                    default:
                        numberOfDays = 0;
                        registrationFees = 0;
                        break;
                }

                //Sets the value for the lodging fee
                switch (cityListBox.SelectedIndex)
                {
                    case 0:
                        lodgingFees = 150;
                        break;
                    case 1:
                        lodgingFees = 225;
                        break;
                    case 2:
                        lodgingFees = 175;
                        break;
                    case 3:
                        lodgingFees = 300;
                        break;
                    case 4:
                        lodgingFees = 175;
                        break;
                    case 5:
                        lodgingFees = 150;
                        break;
                    default:
                        lodgingFees = 0;
                        break;
                }

                //Calculations
                totalLodgingFees = lodgingFees * numberOfDays;
                totalFees = totalLodgingFees + registrationFees;

                //Output
                workshopInfoBuilder.AppendLine($"Registration: {registrationFees:c}");
                workshopInfoBuilder.AppendLine($"Lodging: {lodgingFees:c} X Number of Days: {numberOfDays} days = {totalLodgingFees:c}");
                workshopInfoBuilder.Append($"Total: {totalFees:c}");

               
                registrationTextBox.Text = workshopInfoBuilder.ToString();
                

            }
            

        }

        /// <summary>
        /// Exits the program
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
